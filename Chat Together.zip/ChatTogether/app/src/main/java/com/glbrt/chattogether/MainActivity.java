package com.glbrt.chattogether;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.database.SnapshotParser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    private String mUsername;
    private static final int REQUEST_IMAGE = 2;
    private static final String LOADING_IMAGE_URL = "https://www.google.com/images/spin-32.gif";

    private RecyclerView rvChat;
    private LinearLayoutManager mLinearLayoutManager;
    private ProgressBar progressBar;
    private EditText etMessage;
    private ImageView ivAddMessage;
    private Button btnSend;

    private FirebaseAuth mAuth;
    private DatabaseReference mRoot, mRef;
    private FirebaseRecyclerAdapter<ChatMessage, ChatViewHolder> mFirebaseAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        if (mAuth.getCurrentUser() == null ) {
            Intent intent = new Intent(MainActivity.this, SignInActivity.class);
            startActivity(intent);
            finish();
        }
        setContentView(R.layout.activity_main);

        String userId = mAuth.getCurrentUser().getUid();
        mRoot = FirebaseDatabase.getInstance().getReference();
        mRef = mRoot.child("users").child(userId);
        mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);
                mUsername = user.getFullName();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                mUsername = "Anonymous";
            }
        });

        rvChat = findViewById(R.id.rv_chat);
        progressBar = findViewById(R.id.progressBar);
        etMessage = findViewById(R.id.et_message);
        ivAddMessage = findViewById(R.id.iv_add_message);
        btnSend = findViewById(R.id.btn_send);

        mLinearLayoutManager = new LinearLayoutManager(MainActivity.this);
        mLinearLayoutManager.setStackFromEnd(true);
        rvChat.setLayoutManager(mLinearLayoutManager);

        SnapshotParser<ChatMessage> parser = new SnapshotParser<ChatMessage>() {
            @NonNull
            @Override
            public ChatMessage parseSnapshot(@NonNull DataSnapshot snapshot) {
                ChatMessage chatMessage = snapshot.getValue(ChatMessage.class);
                if (chatMessage != null) {
                    chatMessage.setId(snapshot.getKey());
                }
                return chatMessage;
            }
        };

        mRef = mRoot.child("messages");
        FirebaseRecyclerOptions<ChatMessage> option = new FirebaseRecyclerOptions.Builder<ChatMessage>()
                .setQuery(mRef, parser)
                .build();

        mFirebaseAdapter = new FirebaseRecyclerAdapter<ChatMessage, ChatViewHolder>(option) {
            @Override
            protected void onBindViewHolder(@NonNull ChatViewHolder holder, int position, @NonNull ChatMessage model) {
                progressBar.setVisibility(View.INVISIBLE);
                if (model.getText() != null) {
                    holder.tvMessage.setText(model.getText());
                    holder.tvMessage.setVisibility(View.VISIBLE);
                    holder.ivMessage.setVisibility(View.GONE);
                } else if (model.getImageUrl() != null) {
                    String imageUrl = model.getImageUrl();
                    if (imageUrl.startsWith("gs://")) {
                        StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(imageUrl);
                        storageReference.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                if (task.isSuccessful()) {
                                    String downloadUrl = task.getResult().toString();
                                    Glide.with(holder.ivMessage.getContext())
                                            .load(downloadUrl)
                                            .into(holder.ivMessage);
                                } else {
                                    Log.w(TAG, "Getting download url failed", task.getException());
                                }
                            }
                        });
                    } else {
                        Glide.with(holder.ivMessage.getContext())
                                .load(model.getImageUrl())
                                .into(holder.ivMessage);
                    }
                    holder.ivMessage.setVisibility(View.VISIBLE);
                    holder.tvMessage.setVisibility(View.GONE);
                }
                holder.tvMessage.setText(model.getName());

                ColorGenerator generator = ColorGenerator.MATERIAL;
                TextDrawable textDrawable = TextDrawable.builder()
                        .beginConfig()
                        .width(50)
                        .height(50)
                        .endConfig()
                        .buildRound(getInitialName(mUsername.toUpperCase()), generator.getColor(mAuth.getCurrentUser().getEmail()));
//                        .buildRound(getInitialName(mUsername), generator.getColor(mAuth.getCurrentUser().getEmail()));

//                TextDrawable drawable = TextDrawable.builder().buildRound(getInitialName(mUsername.toUpperCase()),generator.getColor(mAuth.getCurrentUser().getEmail()));

                holder.ivMessager.setImageDrawable(textDrawable);
            }

            @NonNull
            @Override
            public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                LayoutInflater inflater = LayoutInflater.from(parent.getContext());
                return new ChatViewHolder(inflater.inflate(R.layout.item_chat, parent, false));
            }
        };

        mFirebaseAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                int chatMessageCount = mFirebaseAdapter.getItemCount();
                int lastVisiblePosition = mLinearLayoutManager.findLastCompletelyVisibleItemPosition();

                if (lastVisiblePosition == -1 ||
                        (positionStart >= (chatMessageCount - 1) &&
                                lastVisiblePosition == (positionStart - 1))) {
                    rvChat.scrollToPosition(positionStart);
                }

            }
        });

        rvChat.setAdapter(mFirebaseAdapter);

        etMessage.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().length() > 0) {
                    btnSend.setEnabled(true);
                } else {
                    btnSend.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChatMessage chatMessage = new ChatMessage(etMessage.getText().toString(),
                        mUsername,
                        null);

                mRoot.child("messages").push().setValue(chatMessage);
                etMessage.setText("");
            }
        });

        ivAddMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_IMAGE);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        mFirebaseAdapter.startListening();
    }

    protected void onPause() {
        mFirebaseAdapter.stopListening();
        super.onPause();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE) {
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    final Uri uri = data.getData();
                    Log.d(TAG, "Uri : " + uri.toString());

                    ChatMessage tempMessage = new ChatMessage(null, mUsername, LOADING_IMAGE_URL);
                    mRoot.child("messages").push()
                            .setValue(tempMessage, new DatabaseReference.CompletionListener() {
                                @Override
                                public void onComplete(@Nullable DatabaseError error, @NonNull DatabaseReference ref) {
                                    if (error == null) {
                                        String key = ref.getKey();
                                        StorageReference storageReference = FirebaseStorage.getInstance()
                                                .getReference(mAuth.getCurrentUser().getUid())
                                                .child(key)
                                                .child(uri.getLastPathSegment());

                                        putImageInStorage(storageReference, uri, key);
                                    } else {
                                        Log.w(TAG, "Unable to write database", error.toException());
                                    }
                                }
                            });
                }
            }
        }
    }

    private void putImageInStorage(StorageReference storageReference, Uri uri, String key) {
        storageReference.putFile(uri).addOnCompleteListener(MainActivity.this, new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                if (task.isSuccessful()) {
                    task.getResult().getMetadata().getReference().getDownloadUrl()
                            .addOnCompleteListener(MainActivity.this, new OnCompleteListener<Uri>() {
                                @Override
                                public void onComplete(@NonNull Task<Uri> task) {
                                    if (task.isSuccessful()) {
                                        ChatMessage chatMessage = new ChatMessage(null, mUsername, task.getResult().toString());
                                        mRoot.child("messages").child(key).setValue(chatMessage);
                                    }
                                }
                            });
                } else {
                    Log.w(TAG, "Image upload task failed!", task.getException());
                }
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_signout) {
            mAuth.signOut();
            Intent intent = new Intent(MainActivity.this, SignInActivity.class);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private String getInitialName(String fullname) {
        String splitName[] = fullname.split("\\s+");
        int splitCount = splitName.length;

        if (splitCount == 1) {
            return "" + fullname.charAt(0) + fullname.charAt(0);
        } else {
            int firstSpace = fullname.indexOf(" ");
            String firstName = fullname.substring(0, firstSpace);

            int lastSpace = fullname.lastIndexOf(" ");
            String middleName = fullname.substring(firstSpace + 1, lastSpace);
            String lastName = fullname.substring(lastSpace + 1);

            return "" + firstName.charAt(0) + lastName.charAt(0);
        }
    }
}
package com.glbrt.chattogether;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ChatViewHolder extends RecyclerView.ViewHolder {

    public TextView tvMessenger, tvMessage;
    public ImageView ivMessager, ivMessage;

    public ChatViewHolder(@NonNull View itemView) {
        super(itemView);

        tvMessenger = itemView.findViewById(R.id.tv_messenger);
        tvMessage = itemView.findViewById(R.id.tv_message);
        ivMessager = itemView.findViewById(R.id.iv_messenger);
        ivMessage = itemView.findViewById(R.id.iv_message);

    }
}
